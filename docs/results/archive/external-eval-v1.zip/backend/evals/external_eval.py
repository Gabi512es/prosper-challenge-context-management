"""Versioned external adapter: offline checks, pinning, private schema preflight, paid execution."""
import argparse
import asyncio
from dataclasses import asdict
from datetime import datetime
from hashlib import sha256
import io
import json
import os
from pathlib import Path
import unittest
from unittest.mock import patch
from uuid import uuid4

from .external_contract import VERSION, ContractError, PatientDriver, compile_scenario, require
from .external_score import grade, saved_observation, tool_events
from .final_preflight import REFERENCES

BACKEND = Path(__file__).resolve().parents[1]
ROOT = BACKEND.parent
CONFIG = Path(__file__).with_name("external_config.json")
PIN = Path(__file__).with_name("external_pin.json")
EVIDENCE = ROOT / "docs/results/external-offline-validation.json"
REPORTS = ("comparison-proposed-v2-20261109-180827-8752c3.results.json", "comparison-baseline-20261109-182321-c4ee5f.results.json")


def config():
    value = json.loads(CONFIG.read_text())
    require(value["version"] == VERSION and value["model"] == "gpt-4o" and value["concurrency"] == 1
            and value["max_input_tokens"] == 128000 and value["max_completion_tokens"] == 512
            and value["sdk_retries"] == 0 and value["timeout_retries"] is False,
            "configuration_not_supported", "configuration")
    return value


def compile_dataset(data, catalog, count=None):
    from .loader import DEFAULT_CATALOG_PATH, git_blob_sha
    require(isinstance(data, dict), "object_required", "dataset")
    require(not set(data) - {"schema_version", "created_at", "dataset_role", "execution_status", "catalog", "contract", "scenarios"},
            "unsupported_dataset_field", "dataset")
    require(data.get("schema_version") in ("0.1", "external-contract-v1"), "unsupported_schema_version", "schema_version")
    require(isinstance(data.get("catalog"), dict) and data["catalog"].get("blob_sha") == git_blob_sha(DEFAULT_CATALOG_PATH),
            "catalog_pin_mismatch", "catalog.blob_sha")
    require(isinstance(data.get("contract"), dict), "contract_required", "contract")
    require(isinstance(data.get("dataset_role"), str) and bool(data["dataset_role"]), "dataset_role_required", "dataset_role")
    require(not set(data["contract"]) - {"integration", "language", "default_patient_behavior", "identity_is_synthetic",
                "referral_on_file", "confirmation", "availability", "timezone", "slot_horizon", "synchronization", "holdout", "grading"},
            "unsupported_contract_field", "contract")
    require(data["contract"].get("language") == "English" and data["contract"].get("timezone") == "America/Los_Angeles"
            and data["contract"].get("identity_is_synthetic") is True, "unsupported_contract_configuration", "contract")
    require(isinstance(data.get("scenarios"), list) and bool(data["scenarios"]), "scenarios_required", "scenarios")
    if count is not None:
        require(len(data["scenarios"]) == count, "scenario_count_mismatch", "scenarios")
    compiled = [compile_scenario(s, catalog) for s in data["scenarios"]]
    require(len({s["scenario"]["id"] for s in compiled}) == len(compiled), "duplicate_labels", "scenarios.id")
    for key in ("default_patient_behavior", "confirmation", "availability", "grading", "referral_on_file", "slot_horizon"):
        if key in data["contract"]:
            require(isinstance(data["contract"][key], str), "prose_contract_field_required", "contract")
            for item in compiled:
                item["review_required"].append("dataset.contract." + key)
    return compiled


def fingerprints():
    names = {"baseline_agent.py", "agent_runtime.py", "metrics_logging.py", "scheduling_agent.py", "scheduling_dialogue.py", "text_runner.py", "agents/catalog_scheduler.json", "data/catalog.json"}
    names.update(str(p.relative_to(BACKEND)) for folder in ("scheduling", "agent_builder") for p in (BACKEND / folder).glob("*.py"))
    names.update("evals/" + name for name in ("external_contract.py", "external_score.py", "external_eval.py", "external_budget.py", "external_config.json", "scorer.py", "text_integration.py", "spend_guard.py", "dev_matrix.py", "loader.py", "final_preflight.py"))
    names.add("tests/test_external_adapter.py")
    return {name: sha256((BACKEND / name).read_bytes()).hexdigest() for name in sorted(names)}


def verify_pin():
    from importlib.metadata import version
    pinned = json.loads(PIN.read_text())
    require(pinned["version"] == VERSION and pinned["files"] == fingerprints(), "adapter_pin_mismatch", "pin")
    require(sha256(EVIDENCE.read_bytes()).hexdigest() == pinned["offline_evidence_sha256"], "offline_evidence_pin_mismatch", "pin")
    require(all(version(k) == v for k, v in pinned["packages"].items()), "dependency_version_mismatch", "pin")
    return pinned


def load_external(path, kind, catalog):
    """Only called after pinned offline checks. Never prints case data."""
    require(Path(path).resolve().is_relative_to(ROOT) is False, "external_path_required", "path")
    verify_pin()
    raw = Path(path).read_bytes()
    require(sha256(raw).hexdigest() == REFERENCES[kind]["sha256"], "external_hash_mismatch", "source")
    try:
        data = json.loads(raw)
    except (ValueError, UnicodeError):
        raise ContractError("malformed_json", "source") from None
    return compile_dataset(data, catalog, REFERENCES[kind]["recorded_scenarios"])


def replay(catalog, compiled):
    by_label = {c["scenario"]["id"]: c for c in compiled}  # Join saved records only; no behavior dispatch.
    rows = []
    for name in REPORTS:
        path = BACKEND / "logs/evals" / name
        original = json.loads(path.read_text())
        for run in original["runs"]:
            result = grade(by_label[run["scenario_id"]], saved_observation(run), catalog)
            old = {a["name"]: a["passed"] for a in run["assertions"]}
            new = {a["name"]: a["passed"] for a in result["assertions"]}
            rows.append({"source_run_id": original["run_id"], "source_sha256": sha256(path.read_bytes()).hexdigest(),
                "scenario_id": run["scenario_id"], "repetition": run["repetition"], "old_passed": run["passed"],
                "new_status": result["status"], "new_passed": result["passed"],
                "common_assertion_disagreements": {k: {"old": old[k], "new": new[k]} for k in old.keys() & new.keys() if old[k] != new[k]},
                "legacy_checks_not_reproduced_automatically": sorted(old.keys() - new.keys()),
                "new_automatic_failures": [a["name"] for a in result["assertions"] if a["passed"] is False],
                "required_review": result["required_review"],
                "explanation": "New version: prose rules/forbidden/explanation require review; absent saved state stays unknown. No missing trace is reconstructed. Remaining common differences require explicit review."})
    return rows


def validate_dev():
    from scheduling import load_catalog
    from .loader import load_dev_scenarios, DEFAULT_CATALOG_PATH
    from openai.resources.chat.completions import AsyncCompletions
    catalog = load_catalog(DEFAULT_CATALOG_PATH)
    compiled = compile_dataset(load_dev_scenarios(), catalog)
    tested_files = fingerprints()
    with patch.object(AsyncCompletions, "create", side_effect=AssertionError("Offline validation attempted an API call")) as network:
        suite = unittest.defaultTestLoader.loadTestsFromName("tests.test_external_adapter")
        def test_names(group):
            for test in group:
                if isinstance(test, unittest.TestSuite):
                    yield from test_names(test)
                else:
                    yield test.id()
        names = list(test_names(suite))
        capture = io.StringIO()
        tests = unittest.TextTestRunner(stream=capture, verbosity=1).run(suite)
        saved = replay(catalog, compiled)
        network.assert_not_called()
    require(tests.wasSuccessful(), "offline_validation_failed", "tests")
    require(tested_files == fingerprints(), "sources_changed_during_validation", "tests")
    evidence = {"version": VERSION, "api_calls": 0, "external_contents_accessed": False,
        "tested_fingerprints": tested_files, "test_names": names,
        "tests_run": tests.testsRun, "test_failures": len(tests.failures), "test_errors": len(tests.errors),
        "dev_scenarios_compiled": len(compiled), "replay": saved,
        "replay_summary": {"runs": len(saved), "old_passes": sum(r["old_passed"] for r in saved),
            "new_passes": sum(r["new_passed"] for r in saved),
            "review_required": sum(r["new_status"] == "review_required" for r in saved),
            "failed": sum(r["new_status"] == "failed" for r in saved),
            "infrastructure_failure": sum(r["new_status"] == "infrastructure_failure" for r in saved)}}
    EVIDENCE.write_text(json.dumps(evidence, indent=2) + "\n")
    return {k: v for k, v in evidence.items() if k != "replay"}


def pin():
    from importlib.metadata import version
    import subprocess
    from scheduling import load_catalog, SchedulingEngine
    from scheduling_agent import build_scheduling_agent
    from baseline_agent import build_baseline_agent
    from .loader import DEFAULT_CATALOG_PATH, git_blob_sha
    from .version import evaluator_sha256
    evidence = json.loads(EVIDENCE.read_text())
    require(evidence["version"] == VERSION and evidence["test_errors"] == evidence["test_failures"] == 0
            and evidence["api_calls"] == 0 and evidence["external_contents_accessed"] is False, "successful_offline_evidence_required", "pin")
    require(evidence["tested_fingerprints"] == fingerprints(), "untested_source_change", "pin")
    config()
    catalog = load_catalog(DEFAULT_CATALOG_PATH)
    identities = {name: factory(SchedulingEngine(catalog, []), catalog, availability_mode="eval_fixture").session_metadata
                  for name, factory in (("proposed", build_scheduling_agent), ("baseline", build_baseline_agent))}
    require(identities["proposed"]["agent_revision"] == "40db1b587b5790ab2c92bc642edbc55e67f0d44ebd8d4f1267de29e1e86ebdc5"
            and identities["baseline"]["agent_revision"] == "68d02acb9a89a72c279c3410001e2b184438abce7f7c714ce39a0e87ddf4f623"
            and evaluator_sha256() == "97117348b6d00263d60c0561381841e3fc50e843873a53b60e827a8c7415a996",
            "frozen_identity_mismatch", "pin")
    value = {"version": VERSION, "files": fingerprints(), "offline_evidence_sha256": sha256(EVIDENCE.read_bytes()).hexdigest(),
             "configuration_sha256": sha256(CONFIG.read_bytes()).hexdigest(), "paid_authorized": False,
             "git_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
             "catalog_blob_sha": git_blob_sha(DEFAULT_CATALOG_PATH), "agent_identities": identities,
             "legacy_evaluator_behavior_sha256": evaluator_sha256(),
             "packages": {k: version(k) for k in ("pipecat-ai", "pipecat-ai-flows", "openai", "tiktoken")}}
    PIN.write_text(json.dumps(value, indent=2) + "\n")
    return {"version": VERSION, "pin_sha256": sha256(PIN.read_bytes()).hexdigest(), "files": len(value["files"]), "paid_authorized": False}


def live_observation(engine, transcript, context, driver, runner_error=False, infra=False, limited=False):
    return {"state": asdict(engine.state), "bookings": engine.bookings, "transcript": transcript,
        "tool_events": list(tool_events(context)), "driver_events": list(driver.events),
        "tool_attempts": [c["function"]["name"] for m in context for c in m.get("tool_calls", [])],
        "policy_codes": [i["code"] for i in engine._policy_issues(require_identity=True) if i["kind"] == "blocked"],
        "runner_error": runner_error, "infrastructure_failure": infra, "evaluation_limited": limited}


async def run_one(compiled, catalog, arm, run_id, cfg):
    from time import perf_counter
    from scheduling import SchedulingEngine
    from scheduling_agent import build_scheduling_agent
    from baseline_agent import build_baseline_agent
    from text_runner import TextAgentSession
    source = compiled["scenario"]
    engine = SchedulingEngine(catalog, source["availability_fixture"], now=datetime.fromisoformat(cfg["now"]))
    factory = build_scheduling_agent if arm == "proposed" else build_baseline_agent
    builder = factory(engine, catalog, availability_mode=cfg["availability_mode"])
    # Only catalog+fixtures go to the engine/builder. Gold and private fact cards do not.
    session = TextAgentSession(builder=builder, run_id=run_id, faults=source.get("faults", []),
        on_slot_taken=engine.mark_slot_unavailable, turn_timeout=cfg["patient_turn_timeout_seconds"])
    session._runtime.llm._retry_on_timeout = False
    session._runtime.llm._client.max_retries = 0
    driver = PatientDriver.from_compiled(compiled)
    transcript = []; times = []; infra = False; limited = False; runner_error = False
    async def measured(operation, patient_turn):
        start = perf_counter(); done = False
        try:
            result = await operation; done = True; return result
        finally:
            times.append({"patient_turn": patient_turn, "completed": done, "elapsed_ms": round((perf_counter()-start)*1000, 3)})
    try:
        startup = await measured(session.start(), 0)
        transcript.append({"role": "assistant", "text": startup.assistant_text})
        patient_text = source["opening"]
        for turn in range(1, cfg["max_patient_turns"] + 1):
            result = await measured(session.send(patient_text), turn)
            transcript.extend([{"role": "patient", "text": patient_text}, {"role": "assistant", "text": result.assistant_text,
                               "tools": list(result.tool_calls), "node": result.node}])
            observation = live_observation(engine, transcript, session.context_messages, driver)
            scored = grade(compiled, observation, catalog)
            if result.ended or engine.bookings or all(a["passed"] is True for a in scored["assertions"]):
                break  # Required transcript review is still pending, never promoted to pass.
            offered = [engine._present_slot(engine._slots[x]) for x in sorted(engine.state.offered_slot_ids)]
            patient_text = driver.reply(result.assistant_text, catalog, offered, engine.state.last_candidates)
            if patient_text is None:
                limited = True; break
        else:
            limited = True
    except (TimeoutError, ConnectionError):
        infra = runner_error = True
    except Exception as error:
        runner_error = True
        # Pipeline ErrorFrames can wrap provider failures in RuntimeError.
        infra = type(error).__name__ in {"APIConnectionError", "APITimeoutError", "RateLimitError", "InternalServerError"}
        infra |= any(x in str(error).casefold() for x in ("llm completion timeout", "connection error", "rate limit", "apiconnectionerror", "apitimeouterror"))
        limited = not infra
    finally:
        await session.close()
    observation = live_observation(engine, transcript, session.context_messages, driver, runner_error, infra, limited)
    return {**grade(compiled, observation, catalog), "call_id": session.call_id, "run_id": run_id,
            "agent": builder.session_metadata, "transcript": transcript, "patient_turn_metrics": times,
            "driver_events": driver.events, "observation": observation}


async def run_batch(catalog, sets, cfg, args):
    from .external_budget import FinalSpendGuard
    from .dev_matrix import usage_for_call
    run_id = "external-v1-" + datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid4().hex[:6]
    path = BACKEND / "logs/evals" / f"{run_id}.results.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    metrics = path.with_name(run_id + ".jsonl")
    report = {"version": VERSION, "configuration": cfg, "configuration_sha256": sha256(CONFIG.read_bytes()).hexdigest(),
              "adapter_pin_sha256": sha256(PIN.read_bytes()).hexdigest(), "approval_reference": args.approval_ref,
              "run_id": run_id, "runs": [], "complete": False, "metrics_path": str(metrics)}
    plan = [("heldout", arm, c, rep) for arm in ("proposed", "baseline") for c in sets["heldout"] for rep in (1, 2)]
    plan += [("robustness", "proposed", c, 1) for c in sets["robustness"]]
    with FinalSpendGuard(args.max_cost_usd, cfg) as budget:
        def checkpoint():
            rows = [json.loads(x) for x in metrics.read_text().splitlines()] if metrics.exists() else []
            for run in report["runs"]:
                own = [x for x in rows if x["call_id"] == run["call_id"]]
                run["usage"] = usage_for_call(own) if own else None
                if len(own) != run["admitted_requests"] or run["usage"] is None or run["usage"]["cost_usd"] is None:
                    run["known_usage_subtotal"] = run["usage"]
                    run["usage"] = None
            report["budget"] = budget.summary()
            path.write_text(json.dumps(report, default=list, indent=2) + "\n")
        for kind, arm, compiled, repetition in plan:
            if budget.stopped:
                break
            attempt = {"dataset": kind, "arm": arm, "scenario_id": compiled["scenario"]["id"], "repetition": repetition}
            # Journal the attempt before admission; there is deliberately no resume/retry path.
            report["pending_attempt"] = attempt; checkpoint()
            if budget.accounted + budget.ceiling > budget.limit:
                budget.stopped = True
                budget.stop_reason = "Full per-request exposure does not fit; next attempt not admitted"
                report["pending_attempt"]["status"] = "not_admitted_budget"
                break
            before = budget.requests
            result = await run_one(compiled, catalog, arm, run_id, cfg)
            result.update(attempt, admitted_requests=budget.requests-before)
            if budget.stopped:
                result.update(status="incomplete_budget", passed=False, agent_assessment="not_assessable")
            report["runs"].append(result); report.pop("pending_attempt", None); checkpoint()
        report["complete"] = len(report["runs"]) == len(plan) and not budget.stopped
        checkpoint()
    return {"report": str(path), "complete": report["complete"], "budget": report["budget"], "attempts": len(report["runs"])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("validate-dev", "pin", "preflight", "run-paid"))
    parser.add_argument("--heldout-path")
    parser.add_argument("--robustness-path")
    parser.add_argument("--max-cost-usd", default="10")
    parser.add_argument("--approval-ref")
    args = parser.parse_args()
    try:
        if args.command == "validate-dev":
            result = validate_dev()
        elif args.command == "pin":
            result = pin()
        else:
            from scheduling import load_catalog
            from .loader import DEFAULT_CATALOG_PATH
            cfg = config(); catalog = load_catalog(DEFAULT_CATALOG_PATH)
            if args.command == "run-paid":
                require(bool(args.approval_ref), "explicit_approval_reference_required", "approval")
            require(bool(args.heldout_path and args.robustness_path), "explicit_paths_required", "paths")
            sets = {}
            for kind, path in (("heldout", args.heldout_path), ("robustness", args.robustness_path)):
                try:
                    sets[kind] = load_external(path, kind, catalog)
                except ContractError as error:
                    error.external_set = kind
                    raise
            if args.command == "preflight":
                result = {"version": VERSION, "pin_verified": True, "api_calls": 0, "scenario_contents_printed": False,
                    "sets": {k: {"schema_compatible": True, "scenarios": len(v), "requiring_manual_review": sum(bool(c["review_required"]) for c in v)} for k, v in sets.items()}}
                (ROOT / "docs/results/external-preflight.json").write_text(json.dumps(result, indent=2) + "\n")
            else:
                result = asyncio.run(run_batch(catalog, sets, cfg, args))
        print(json.dumps(result, indent=2))
        return 0
    except ContractError as error:
        result = {"status": "unsupported", "code": error.code, "field": error.path, "api_calls": 0,
                  "external_set": getattr(error, "external_set", None),
                  "scenario_contents_printed": False, "no_scenario_change": True}
        if args.command == "preflight":
            (ROOT / "docs/results/external-preflight.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
